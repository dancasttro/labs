#Welcome

This style guide is an example of what
[hologram](http://trulia.github.io/hologram)  can help you build and
maintain.

The goal of hologram is to make it easy to document your CSS and to
display the code examples to use that CSS. Hologram has no
opinions about how you should actually organize/style your style guide.
You could do everything as a single file with no header/footer and it
would work just fine. Or, you could break it up into an individual file
for each component. Top navigation, left navigation, no
navigation....that's up to you. Build it however you'd like.  


We've borrowed some of [Trulia](http://trulia.com)'s own CSS library to
demonstrate how hologram can be used. If you want more details about
hologram see the [git repository](http://github.com/trulia/hologram).  


This is a work in progress, please consider contributing to
[hologram](http://github.com/trulia/hologram).

